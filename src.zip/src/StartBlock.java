@SuppressWarnings("serial")
public class StartBlock extends Box {	

	public StartBlock(String texture) {		
	    super(texture);
	    this.setCollisionMode(COLLISION_CHECK_NONE);
	}
}